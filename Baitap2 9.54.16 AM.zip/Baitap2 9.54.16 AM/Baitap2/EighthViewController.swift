//
//  EighthViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/19/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class EighthViewController: UIViewController {
    
    @IBOutlet weak var imgPass1: UIImageView!
    @IBOutlet weak var imgPass2: UIImageView!
    @IBOutlet weak var imgPass3: UIImageView!
    @IBOutlet weak var imgPass4: UIImageView!
    @IBOutlet weak var imgPass1check: UIImageView!
    @IBOutlet weak var imgPass2Check: UIImageView!
    @IBOutlet weak var imgPass3Check: UIImageView!
    @IBOutlet weak var imgPass4Check: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        imgPass1.isHidden = false
        imgPass2.isHidden = false
        imgPass3.isHidden = false
        imgPass4.isHidden = false
        imgPass1check.isHidden = true
        imgPass2Check.isHidden = true
        imgPass3Check.isHidden = true
        imgPass4Check.isHidden = true
   
    }
    
  
    //MARK: IBAction
    var password = 0
    var giatri:String = ""
    
    @IBAction func btn1(_ sender: UIButton)
    {
        giatri = giatri + " "+"1"
        LoadPass()
        print(giatri)
        DKmovepage()
  
    }
    
    @IBAction func btn2(_ sender: Any){
        LoadPass()
        giatri = giatri + " "+"2"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn3(_ sender: Any){
        LoadPass()
        giatri = giatri + " "+"3"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn4(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"4"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn5(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"5"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn6(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"6"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn7(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"7"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn8(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"8"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn9(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"9"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btn0(_ sender: Any) {
        LoadPass()
        giatri = giatri + " "+"0"
        print(giatri)
        DKmovepage()
    }
    
    @IBAction func btnDel(_ sender: Any) {
        let vc = NinethViewController(nibName: "NinethViewController", bundle: nil)
        vc.text = giatri
        
        navigationController?.pushViewController(vc, animated: true)
        print(vc)
    }
    
    func LoadPass() {

        if(imgPass1.isHidden == false)
        {
            imgPass1.isHidden = true
            imgPass1check.isHidden = false
            password = password + 1
        }
        else if (imgPass2.isHidden == false)
        {
            imgPass2.isHidden = true
            imgPass2Check.isHidden = false
            password = password + 1
            
        }
        else if (imgPass3.isHidden == false)
        {
            imgPass3.isHidden = true
            imgPass3Check.isHidden = false
            password = password + 1
            
        }
        else if (imgPass4.isHidden == false)
        {
            imgPass4.isHidden = true
            imgPass4Check.isHidden = false
            password = password + 1
            
        }
        
       
        
    }
    func DKmovepage() {
        if(password >= 4)
        {
            let vc = NinethViewController(nibName: "NinethViewController", bundle: nil)
            vc.text = giatri
            navigationController?.pushViewController(vc, animated: true)
            print(vc)
        }
    }
    
    
}
