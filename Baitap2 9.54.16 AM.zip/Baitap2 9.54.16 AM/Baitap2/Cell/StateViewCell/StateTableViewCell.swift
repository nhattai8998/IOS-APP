//
//  StateTableViewCell.swift
//  Baitap2
//
//  Created by MacMini on 4/19/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class StateTableViewCell: UITableViewCell {
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var imgTisk: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the vew for the selected state
  
        imgTisk.isHidden = true
        
        if(isSelected == true)
        {
            imgTisk.isHidden = false
            lblState.font = UIFont(name: "Avenir-Heavy", size: 16.0)

            lblState.highlightedTextColor = UIColor(red: 0/255, green: 71/255, blue:  137/255, alpha: 1)
        }
        else
        {
            print("Fail")
            imgTisk.isHidden = true
            lblState.font = UIFont(name: "Avenir-Medium", size: 16.0)
        }
    }
    func  commIntit(_ lblname: String)
    {
        lblState.text = lblname
    }
    
}
