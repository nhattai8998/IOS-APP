//
//  CreaterecommendTableViewCell.swift
//  Baitap2
//
//  Created by MacMini on 4/18/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class CreaterecommendTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
