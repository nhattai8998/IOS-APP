//
//  CreaterecommendCollectionViewCell.swift
//  Baitap2
//
//  Created by MacMini on 4/18/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class CreaterecommendCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
