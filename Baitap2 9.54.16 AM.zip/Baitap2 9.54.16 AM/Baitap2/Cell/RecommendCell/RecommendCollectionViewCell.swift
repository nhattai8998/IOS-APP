//
//  RecommendCollectionViewCell.swift
//  Baitap2
//
//  Created by MacMini on 4/16/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class RecommendCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
