//
//  ThirdViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/12/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    //MARK: outlet
    //MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    //MARK: IBAction
    
    @IBAction func signinAction(_ sender: UIButton) {
        let newViewController = FourthViewController()
        self.navigationController?.pushViewController(newViewController, animated:  true)
    }
    
}
