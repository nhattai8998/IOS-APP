//
//  SixthViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/18/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class SixthViewController: UIViewController {
    //MARK: Outlet
    @IBOutlet weak var colTripTableView: UITableView!
    
    //MARK: Params
    var sourcetriptableview: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    
    let namesourcetriptableview = "SourceTripTableViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //register collection
        colTripTableView.register(UINib.init(nibName: namesourcetriptableview, bundle: nil), forCellReuseIdentifier: namesourcetriptableview)
        colTripTableView.delegate = self
        colTripTableView.dataSource = self
    }
    
    //MARK: IBAction
    @IBAction func backAction(_ sender: UIButton) {
        
        //Navigate to
        let newViewController = FifthViewController()
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    
    
}

//MARK: COLLECTION
extension SixthViewController: UITableViewDelegate, UITableViewDataSource 
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == colTripTableView
        {
            return sourcetriptableview.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: namesourcetriptableview, for: indexPath) as! SourceTripTableViewCell
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let newViewController = FifthViewController()
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    
    
    
    
    
    
    
}
