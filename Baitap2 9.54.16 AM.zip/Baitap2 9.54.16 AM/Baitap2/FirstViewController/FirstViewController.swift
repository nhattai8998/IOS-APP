//
//  FirstViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/11/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    //MARK: outlet

    
    //MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        print("Screen First")
    }

    //MARK: IBAction
    @IBAction func signInEmailAction(_ sender: UIButton) {
        //rint("Click Email")
        //Navigate to Email and pop
        let newViewController = ThirdViewController()
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    

    
    @IBAction func signUpAction(_ sender: UIButton)
    {
        let newViewController = SecondViewController()
        self.navigationController?.pushViewController(newViewController, animated: true)
        
    }
    

    
   


}
