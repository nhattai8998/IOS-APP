//
//  FourthViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/12/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {
    //MARK: Outlet
    @IBOutlet weak var colRecommend: UICollectionView!
    @IBOutlet weak var colCaterogy: UICollectionView!
    @IBOutlet weak var colCountry: UICollectionView!

    @IBOutlet weak var colNewproduct: UICollectionView!
    @IBOutlet weak var coltrandingproduct: UICollectionView!
    @IBOutlet weak var colHotProduct: UICollectionView!
    
    
    
    //MARK: Params
    var recommends: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    var caterogy: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    var country: [Int] = [0,1,2,3,4,5,6,7,8,9]
    var hotproduct: [Int] = [0,1,2,3,4,5,6,7,8,9]
    var newproduct: [Int] = [0,1,2,3,4,5,6,7,8,9]
    var trandingroduct: [Int] = [0,1,2,3,4,5,6,7,8,9]
    
    let nametrandingproduct = "TrandingproductCollectionViewCell"
    let namenewproduct = "NewprodutCollectionViewCell"
    let namehotproduct = "HotproductCollectionViewCell"
    let nameCountry = "CountryCollectionViewCell"
    let nameCaterogy = "CaterogyCollectionViewCell"
    let nameRecommend = "RecommendCollectionViewCell"
    let nameCreate = "CreateCollectionViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //register collection
        colRecommend.register(UINib.init(nibName: nameCountry, bundle: nil), forCellWithReuseIdentifier: nameCountry)
        
        colRecommend.register(UINib.init(nibName: nameCreate, bundle: nil), forCellWithReuseIdentifier: nameCreate)
        colCaterogy.register(UINib.init(nibName: nameCaterogy, bundle: nil), forCellWithReuseIdentifier: nameCaterogy)
        colCountry.register(UINib.init(nibName: nameCountry, bundle: nil), forCellWithReuseIdentifier: nameCountry)
        colHotProduct.register(UINib.init(nibName: namehotproduct, bundle: nil), forCellWithReuseIdentifier: namehotproduct)
        colNewproduct.register(UINib.init(nibName: namenewproduct, bundle: nil), forCellWithReuseIdentifier: namenewproduct)
        coltrandingproduct.register(UINib.init(nibName: nametrandingproduct, bundle: nil), forCellWithReuseIdentifier: nametrandingproduct)
        
        coltrandingproduct.delegate = self
        coltrandingproduct.dataSource = self
        colNewproduct.delegate = self
        colNewproduct.dataSource = self
        colCountry.delegate = self
        colCountry.dataSource = self
        colCaterogy.delegate = self
        colCaterogy.dataSource = self
        colRecommend.delegate = self
        colRecommend.dataSource = self
        colHotProduct.delegate = self
        colHotProduct.dataSource = self
        
    }
}

//MARK: COLLECTION
extension FourthViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView == colRecommend
        {
            return recommends.count
        }
        else if collectionView == colCaterogy
        {
            return caterogy.count
        }
        else if collectionView == colCountry
        {
            return country.count
        }
        else if collectionView == colHotProduct
        {
            return hotproduct.count
        }
        else if collectionView == colNewproduct
        {
            return newproduct.count
        }
        else if collectionView == coltrandingproduct
        {
            return trandingroduct.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == colRecommend
        {
            if indexPath.item == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nameCreate, for: indexPath) as! CreateCollectionViewCell
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nameCountry, for: indexPath) as! CountryCollectionViewCell
                return cell
            }
        }
        else if collectionView == colCaterogy
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nameCaterogy, for: indexPath) as! CaterogyCollectionViewCell
            return cell
        }else if collectionView == colCountry
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nameCountry, for: indexPath) as! CountryCollectionViewCell
            return cell
        }
        else if collectionView == colHotProduct
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namehotproduct, for: indexPath) as! HotproductCollectionViewCell
            return cell
            
        }
        else if collectionView == colNewproduct
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namenewproduct, for: indexPath) as! NewprodutCollectionViewCell
            return cell
            
        }
        else if collectionView == coltrandingproduct
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nametrandingproduct, for: indexPath) as! TrandingproductCollectionViewCell
            return cell
            
        }
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nameCaterogy, for: indexPath) as! CaterogyCollectionViewCell
        return cell

        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if collectionView == colRecommend
        {
            return CGSize.init(width: 164.5, height: 197.5  )
        }
        else if collectionView == colCaterogy
        {
            return CGSize.init(width: 164.5, height: 197.5  )
        }
        else if collectionView == colCountry
        {
            return CGSize.init(width: 165, height: 198)
        }
        else if collectionView==colHotProduct
        {
            return CGSize.init(width: 164, height: 197)
        }
        else if collectionView==colNewproduct
        {
            return CGSize.init(width: 164, height: 197)
        }
        else if collectionView==coltrandingproduct
        {
            return CGSize.init(width: 164, height: 197)
        }
        
        
        return CGSize.init(width: 165 , height: 198  )
        
    }


}
//MARK: CATEROGY
