//
//  FifthCollectionViewCell.swift
//  Baitap2
//
//  Created by MacMini on 4/17/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class FifthCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
