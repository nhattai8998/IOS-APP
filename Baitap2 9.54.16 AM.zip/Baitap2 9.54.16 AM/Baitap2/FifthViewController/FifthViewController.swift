//
//  FifthViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/17/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class FifthViewController: UIViewController {
    //MARK: Outlet
    
    @IBOutlet weak var colCreaterecommen: UICollectionView!
    @IBOutlet weak var colCaterogyrequest: UICollectionView!
    @IBOutlet weak var colCountryrequest: UICollectionView!
    @IBOutlet weak var colRecentrequest: UICollectionView!
    @IBOutlet weak var colTableView: UITableView!
    
    //MARK: Params
    var triptableview: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    var createrecommens: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    var caterogyrequests: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    var countryrequests: [Int] = [0, 1, 2, 3, 4, 5, 6, 7 ,8 ,9]
    var recentrequests: [Int] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var createcommend: [Int] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    let namecreaterecommend = "CreaterecommendCollectionViewCell"
    let nametableview = "YourTripTableViewCell"
    let namerecentrequest = "RecentrequestsCollectionViewCell"
    let namecountryrequest = "CountryrequestCollectionViewCell"
    let namecaterogyrequest = "CaterogyrequesrCollectionViewCell"
    let namecreaterecommen = "CreaterecommenCollectionViewCell"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //register collection
        colRecentrequest.register(UINib.init(nibName: namerecentrequest, bundle: nil), forCellWithReuseIdentifier: namerecentrequest)
        colCaterogyrequest.register(UINib.init(nibName: namecaterogyrequest, bundle: nil), forCellWithReuseIdentifier: namecaterogyrequest)
        colCreaterecommen.register(UINib.init(nibName: namecreaterecommen, bundle: nil), forCellWithReuseIdentifier: namecreaterecommen)
        colCreaterecommen.register(UINib.init(nibName: namecreaterecommend, bundle: nil), forCellWithReuseIdentifier: namecreaterecommend)
        colCountryrequest.register(UINib.init(nibName: namecountryrequest, bundle: nil), forCellWithReuseIdentifier: namecountryrequest)
        colTableView.register(UINib.init(nibName: nametableview, bundle: nil), forCellReuseIdentifier: nametableview)
        
        
        
        colTableView.delegate = self
        colTableView.dataSource = self
        colRecentrequest.delegate = self
        colRecentrequest.dataSource = self
        colCountryrequest.delegate = self
        colCountryrequest.dataSource = self
        colCaterogyrequest.delegate = self
        colCaterogyrequest.dataSource = self
        colCreaterecommen.delegate = self
        colCreaterecommen.dataSource = self
    }
}

    //MARK: COLLECTION
extension FifthViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource
{
    //------------------------TABLE VIEW--------------------------------
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == colTableView
        {
            return triptableview.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: nametableview, for: indexPath) as! YourTripTableViewCell
            return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let newViewController = SixthViewController()
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    //-------------------------COLLECTION VIEW---------------------------
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView == colCreaterecommen
        {
            return createrecommens.count
        }
        else if collectionView == colCaterogyrequest        {
            return caterogyrequests.count
        }
        else if collectionView == colCountryrequest        {
            return countryrequests.count
        }
        else if collectionView == colRecentrequest        {
            return recentrequests.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == colCreaterecommen
            {
                if indexPath.item == 0 {
                    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namecreaterecommend, for: indexPath) as! CreaterecommendCollectionViewCell
                    return cell
                } else {
                    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namecreaterecommen, for: indexPath) as! CreaterecommenCollectionViewCell
                    return cell
                }

            }
        else if collectionView == colCaterogyrequest
            {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namecaterogyrequest, for: indexPath) as! CaterogyrequesrCollectionViewCell
                return cell
            }
        else if collectionView == colCountryrequest
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namecountryrequest, for: indexPath) as! CountryrequestCollectionViewCell
            return cell
        }
        else if collectionView == colRecentrequest
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namerecentrequest, for: indexPath) as! RecentrequestsCollectionViewCell
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: namecreaterecommen, for: indexPath) as! CreaterecommenCollectionViewCell
        return cell
        
    }
    
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
            if collectionView == colCreaterecommen
            {
                return CGSize.init(width: 164.3, height: 208.8  )
            }
            else if collectionView == colCaterogyrequest
            {
                return CGSize.init(width: 164.3, height: 208.8  )
            }
            else if collectionView == colCountryrequest
            {
                return CGSize.init(width: 164.3, height: 208.8  )
            }
            else if collectionView == colCountryrequest
            {
                return CGSize.init(width: 164.3, height: 208.8  )
            }
            return CGSize.init(width: 164.3, height: 208.8  )
        }
    
    


}
