//
//  SecondViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/11/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
//MARK: outlet
//MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

       // Do any additional setup after loading the view.
    }


 //MARK: IBAction
    
    @IBAction func sigunbackAction(_ sender: UIButton) {
        let newViewController = FifthViewController()
        self.navigationController?.pushViewController(newViewController, animated:  true)
    }
    
}



