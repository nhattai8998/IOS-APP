//
//  NinethViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/23/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class NinethViewController: UIViewController {
    
    var text:String = ""
    
    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var NumberPhoneTextFiled: UITextField!
    
    @IBOutlet weak var phoneTextfield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NumberPhoneTextFiled?.text = text
        
    }
    
    
    
    
    //MARK: IBAction
    @IBAction func signAction(_ sender: UIButton)
    {
        let signpagetenth = TenthViewController(nibName: "TenthViewController", bundle: nil)
        navigationController?.pushViewController(signpagetenth, animated: true)
        
    }
    
    @IBAction func backPage8(_ sender: UIButton) {
        let vc = EighthViewController(nibName: "EighthViewController", bundle: nil)
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
}

