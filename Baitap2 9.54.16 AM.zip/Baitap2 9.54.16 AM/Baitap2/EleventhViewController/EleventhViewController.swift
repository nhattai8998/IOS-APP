//
//  EleventhViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/25/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class EleventhViewController: UIViewController {

    @IBOutlet weak var Imageview: UIImageView!
    var getImage = UIImage()
    
    @IBOutlet weak var imgImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imgImage.image = getImage
        print(getImage)
        // Do any additional setup after loading the view.
    }




}
