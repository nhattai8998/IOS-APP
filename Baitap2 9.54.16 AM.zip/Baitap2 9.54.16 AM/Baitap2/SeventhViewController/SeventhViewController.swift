//
//  SeventhViewController.swift
//  Baitap2
//
//  Created by MacMini on 4/19/19.
//  Copyright © 2019 MacMini. All rights reserved.
//

import UIKit

class SeventhViewController: UIViewController {
    //MARK: Outlet
  
    @IBOutlet weak var colStateTableView: UITableView!
    
    //MARK: Params
    let items: [String] = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho"]
    
    let nameStatetableview = "StateTableViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //register collection
        
        colStateTableView.register(UINib.init(nibName: nameStatetableview, bundle: nil), forCellReuseIdentifier: nameStatetableview)
        colStateTableView.delegate = self
        colStateTableView.dataSource = self
    
        
      
    //MARK: COLLECTION
}
    
}

extension SeventhViewController: UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == colStateTableView
        {
            return items.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: nameStatetableview, for: indexPath) as! StateTableViewCell
        cell.commIntit(items[indexPath.item])

            print(indexPath.item)
            print("-------------")
    
        return cell
    }
    
    
}
